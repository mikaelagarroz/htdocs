
<!DOCTYPE html> 
<html>

<head>
    <meta charset="UTF8" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Kommentera</title> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
</head>

    <body>
        
        <header>
            <div class="container">
                <h1>Kommentarsida</h1>
                <nav>
                    <ul>
                        <li><a href="#">HEM</a></li>
                        <li><a href="#">OM</a></li>
                        <li><a href="#">KONTAKT</a></li>
                        <li><a href="logOutProcess.php">LOGGA UT</a></li>
                        <!--<form action="logOutProcess.php" method="post">
                        <button type="submit" name="logOut" id="logOut" class="loginbtn">Logga ut</button>-->
                        </form>
                    </ul>
                </nav>
            </div>
        </header>

        <h3>Kommentera gärna om du vill</h3>

        <?php

/* Starta session, för att man ska hållas inloggad,
vill kolla att det är rätt "sessionvariabel" */
session_start();

if(isset($_SESSION['email'])){

echo 'Välkommen, '.$_SESSION['email'];

}
else{
    header("Location: login.php");
}
?>        
<!-- Formulär del-->
        
    <form id="form" action="commentProcess.php" method="post">

        <!--<label for="name">Namn:</label><br>
        <input type="text" id="name" name="name" required><br>-->
        <label for="comment">Kommentar:</label><br>
        <input type="text" id="comment" name="comment"><br>
        <br>
        <button type="submit" class="submitComment">Submit</button>
        
    </form> 


    </body>

</html>
