<!DOCTYPE html> 
<html>

<head>
    <meta charset="UTF8" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Mitt formulär</title> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
    
<header>
            <div class="container">
                <h1>Kommentarsida</h1>
                <nav>
                    <ul>
                        <li><a href="#">HEM</a></li>
                        <li><a href="#">OM</a></li>
                        <li><a href="#">KONTAKT</a></li>
                        <li><a href="logOutProcess.php">LOGGA UT</a></li>
                        <!--<form action="logOutProcess.php" method="post">
                        <button type="submit" name="logOut" class="loginbtn">Logga ut</button>-->
                        </form>

                    </ul>
                </nav>
            </div>
        </header>

        <h3>Kommentarer:</h3>
</body>
</html>

<?php
session_start();

if(isset($_SESSION['email'])){

}
else{
    header("Location: login.php");
}

    //$name = $_POST['name'];
    $comment = $_POST['comment'];
    $email = $_SESSION['email'];

    LäggaTillKommentar($comment, $email);

    $db = new Sqlite3('./db/labb2.db'); 

$select = $db->query("SELECT kom_text, epost FROM 'kommentar', 'labb2' WHERE k_epost=epost");

 while($row = $select->fetchArray())
    {
    
        // Den som kommenterar ska sparas som avsändare
        //echo $_SESSION['email'];
        echo 'Avsändare: '.$row['epost'];
        echo '<br>';
        echo 'Kommentar: '.$row['kom_text'];
        echo '<hr>';
        
    }
    $db->close();

?>

<?php

    function LäggaTillKommentar($comment, $email){
        $db = new Sqlite3('./db/labb2.db');
        $sql = "INSERT INTO 'kommentar'('kom_text', 'k_epost') VALUES (:comment, :email)";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':email', $email, SQLITE3_TEXT);
        $stmt->bindParam(':comment', $comment, SQLITE3_TEXT);

        if($stmt->execute()){
            $db->close();
            return true;
        }
        else{
            $db->close();
            return false;
        }


    }


?> 