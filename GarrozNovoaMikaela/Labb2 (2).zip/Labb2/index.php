<?php
    
    function unique_salt() {
 
        return substr(sha1(mt_rand()),0,22);
       }

    $db = new Sqlite3('./db/labb2.db');
    $email= $_POST['email'];
    $psw = $_POST['psw'];
    $salt = unique_salt();
    $hash = sha1($salt.$psw);

//$result = $db->query("INSERT INTO 'labb2' ('epost', 'password', 'salt') VALUES ('$email','$hash','$salt')");

// Ska hindra duplicering av email, ge något meddelande till anv. om att mail är upptagen
$check_email = $db->querySingle("SELECT COUNT(epost) FROM 'labb2' WHERE epost='".$email."'"); 

if($check_email > 0){
    
$error_mail = 'Mailadressen används redan.';
header("Location: registration.php?error=".$error_mail);

}else{
    $result = $db->query("INSERT INTO 'labb2' ('epost', 'lösenord', 'salt') VALUES ('$email','$hash','$salt')");
    $sucess = 'Registreringen blev lyckad!';
    header("Location: login.php?sucess=".$sucess);
}
   
// Satt epost till unique i databasen !!

$db->close();
   

?>