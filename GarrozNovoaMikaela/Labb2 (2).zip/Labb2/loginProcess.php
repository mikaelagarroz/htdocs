<?php


$db = new Sqlite3('./db/labb2.db');

// Hämtar ut från login sidan
$email = $_POST['email'];
$psw = $_POST['psw'];

// Hämtar saltet och password, mailen som skrivs in ska matcha med den som är i databasen
$p_result = $db->query("SELECT salt, password FROM 'labb2' WHERE '".$email."'=epost"); 

$row = $p_result->fetchArray(); // row innehåller både salt och lösenord
$salt = $row['salt'];
$hash = sha1($salt.$psw);

$db->close();
if($hash==$row['password']) 
{
    session_start();
    $_SESSION['email'] = $email;
    header("Location: comment.php");
    
}
else
{
    header("Location: login.php");
    
}
$db->close();
    

?>