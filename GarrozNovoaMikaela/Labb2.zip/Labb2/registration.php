<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF8" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Labb2</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
</head>

    <body>
    <header>
            <div class="container">
                <h1>STARTSIDA</h1>
                <nav>
                    <ul>
                        <li><a href="#">HOME</a></li>
                        <li><a href="#">ABOUT</a></li>
                        <li><a href="#">CONTACT</a></li>
                    </ul>
                </nav>
            </div>
        </header>

<div>

    <form action="index.php" method="post">
        <div class="container">
            <h2>Register</h2>
            <p>Please fill in this form to create an account.</p>
            <hr>

            <label for="email"><b>Email</b></label>
            <input type="text" id="email" placeholder="Enter Email" name="email" required
            pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">

            <label for="psw"><b>Password</b></label>
            <input type="password" id="psw" placeholder="Enter Password" name="psw" required>

            <label for="psw-repeat"><b>Repeat Password</b></label>
            <input type="password" id="psw-repeat" placeholder="Repeat Password" name="psw-repeat" required>
            <hr>

            <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
            <button type="submit" id="register" name="create" class="registerbtn">Register</button>

        </div>
    </form> 

</div>

        <form action="login.php" method="post">
            <div class="container signin">
                <p>Already have an account?</p>
                <button type="submit" name="signIn" class="signInbtn">Sign in</button>
            </div>
        </form>


<!-- Alert -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script type="text/javascript">

$(function(){
    $('#register').click(function(){

        swal.fire({
            'title': 'Hello World',
            'text': 'Hello World',
            'text': 'success'
        })
        
        /*var valid = this.form.checkValidity();

        if(valid){

        var email = $('#email').val();
        var psw = $('#psw').val();
        var psw-repeat = $('#psw-repeat').val();

            e.prevenDefault(); //hindrar 
            
            $.ajax({
               type: 'POST', 
               url: 'index.php'
               data: {email: email,psw: psw,psw-repeat: psw-repeat}, 
               sucesss: function(data){
                Swal.fire({
                'title': 'Successful',
                'text': 'User registred',
                'type': 'success'
                })
                
               },
               error: function(data){
                Swal.fire({
                'title': 'Errors',
                'text': 'User not registred',
                'type': 'error'
                })

                }
            });

           
        }else{
            
        }

        
        });*/
       
        
    });   
 
</script>
    </body>

</html>