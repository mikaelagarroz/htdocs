<?php

session_start();

if(isset($_SESSION['email'])){

echo 'Välkommen, '.$_SESSION['email'];

}
else{
    header("Location: login.php");
}

?>

<!DOCTYPE html> 
<html>

<head>
    <meta charset="UTF8" />
    <link rel="stylesheet" type="text/css" href="commentStyle.css">
    <title>Mitt formulär</title> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>

<?php

$db = new Sqlite3('./db/labb2.db');
    $name = $_POST['name'];
    $comment = $_POST['comment'];
    //$result = $db->query("INSERT INTO 'kommentar' ('namn', 'emailadress', 'text') VALUES ('$name','$mail','$comment')");
    LäggaTillKommentar($name, $comment);


 
//$version = $db->querySingle('SELECT SQLITE_VERSION()');
 
//echo $version . "\n"; 

$select = $db->query("SELECT * FROM 'kommentar'");

 while($row = $select->fetchArray())
    {
        
        echo '<div id="Namn">'.$row['namn'].'</div>';
        echo '<br>';
        echo $row['kom_text'];
        echo '<br>';
        
    }
    $db->close();

?>

<?php

    function LäggaTillKommentar($namn, $comment){
        $db = new Sqlite3('./db/labb2.db');
        $sql = "INSERT INTO 'kommentar'('namn', 'kom_text') VALUES ( :namn, :comment)";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':namn', $namn, SQLITE3_TEXT);
        $stmt->bindParam(':comment', $comment, SQLITE3_TEXT);

        if($stmt->execute()){
            $db->close();
            return true;
        }
        else{
            $db->close();
            return false;
        }


    }
    $db->close();


?> 