
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF8" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Labb2</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
</head>

    <body>
    <header>
            <div class="container">
                <h1>STARTSIDA</h1>
                <nav>
                    <ul>
                        <li><a href="#">HOME</a></li>
                        <li><a href="#">ABOUT</a></li>
                        <li><a href="#">CONTACT</a></li>
                    </ul>
                </nav>
            </div>
        </header>

<div>
    <!-- Login form -->
    <form action="loginProcess.php" method="post">
        <div class="container">
            <h2>Sign in</h2>
            <p>Please fill in this form to sign in.</p>
            <hr>

            <label for="email"><b>Email</b></label>
            <input type="text" placeholder="Enter Email" name="email" required 
             pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
            

            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="psw" required>
            <hr>

            <button type="submit" name="login" class="loginbtn">Sign in</button>

        </div>
    </form> 

</div>  

    <body>
    <header>