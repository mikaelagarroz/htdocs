<?php

/* Starta session, för att man ska hållas inloggad,
vill kolla att det är rätt "sessionvariabel" */
session_start();

//$_SESSION['email'] =$email; 

if(isset($_SESSION['email'])){

echo 'Välkommen, '.$_SESSION['email'];

}
else{
    header("Location: login.php");
}
?>

<!DOCTYPE html> 
<html>

<head>
    <meta charset="UTF8" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Kommentera</title> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
</head>

    <body>
        
        <header>
            <div class="container">
                <h1>STARTSIDA</h1>
                <nav>
                    <ul>
                        <li><a href="#">HOME</a></li>
                        <li><a href="#">ABOUT</a></li>
                        <li><a href="#">CONTACT</a></li>
                    </ul>
                </nav>
            </div>
        </header>

        <h3>Kommentera</h3>
        <p>Kommentera gärna om du vill</p>


<!-- Formulär del-->
        
    <form id="form" action="commentProcess.php" method="post">

        <label for="name">Namn:</label><br>
        <input type="text" id="name" name="name" required><br>
        <label for="comment">Kommentar:</label><br>
        <input type="comment" id="comment" name="comment"><br>
        <br>
        <button type="submit">Submit</button>
       
        <!-- <input type="button" value="Validate" id="submitBtn" class="button">-->
        
        
    </form> 


    </body>

</html>
