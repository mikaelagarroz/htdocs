<?php
    
    function unique_salt() {
 
        return substr(sha1(mt_rand()),0,22);
       }

    $db = new Sqlite3('./db/labb2.db');
    $email= $_POST['email'];
    $psw = $_POST['psw'];
    $salt = unique_salt();
    $hash = sha1($salt.$psw);



   $result = $db->query("INSERT INTO 'labb2' ('epost', 'password', 'salt') VALUES ('$email','$hash','$salt')");

    
   $db->close();
   header("Location: login.php");
//echo $version . "\n"; 

/*$result = $db->query("SELECT * FROM 'labb2'");

if($result){
    echo 'User saved.';
}else{
    echo 'error';
}
//$version = $db->querySingle('SELECT SQLITE_VERSION()');

 while($row = $result->fetchArray())
    {
        
        echo '<div id="Email">'.$row['epost'].'</div>';
        echo '<br>';
        echo $row['password'];
        echo '<br>';
        echo $row['salt'];
        echo '<br>';
        
    }*/


?>